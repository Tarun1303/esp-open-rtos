from __future__ import annotations

import argparse
import json
import mimetypes
import os
import signal
import threading
import time
import urllib.parse
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from engine import NetworkRuntime, PhysicsNetwork, TemporalPatternRegistry

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
RUNTIME_DIR = ROOT / "runtime"
STATE_FILE = Path(os.environ.get("STATE_FILE", str(RUNTIME_DIR / "state-v3.json"))).expanduser().resolve()
STATE_FILE.parent.mkdir(parents=True, exist_ok=True)


def load_runtime() -> tuple[NetworkRuntime, bool]:
    network = PhysicsNetwork(seed=7, background_rate=3.0)
    registry = TemporalPatternRegistry(neurons=network.n, bins=network.FINGERPRINT_BINS)
    runtime = NetworkRuntime(network, registry)
    resume_teaching = False
    if not STATE_FILE.is_file():
        return runtime, resume_teaching
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        parameters = data.get("physics_parameters", {})
        if isinstance(parameters, dict):
            for name in network.PHYSICS_PARAMETER_NAMES:
                if name in parameters:
                    setattr(network, name, float(parameters[name]))
        areas = data.get("areas", [])
        if len(areas) == len(network.directed_edges):
            for edge, area in zip(network.directed_edges, areas):
                edge.area = max(network.area_min, min(float(area), network.area_max))
            network._normalise_outgoing_material()
        if isinstance(data.get("registry"), dict):
            registry = TemporalPatternRegistry.from_dict(data["registry"])
            if registry.neurons == network.n and registry.bins == network.FINGERPRINT_BINS:
                runtime.registry = registry
        network.background_rate = max(0.0, min(float(data.get("background_rate", 3.0)), 12.0))
        runtime.speed = max(0.25, min(float(data.get("speed", 10.0)), 50.0))
        runtime.teaching_cycles = max(0, int(data.get("teaching_cycles", 0)))
        runtime.teach_expression = str(data.get("teach_expression", "1+1"))
        runtime.teach_label = str(data.get("teach_label", "2"))
        if isinstance(data.get("last_closed_loop"), dict):
            runtime.last_closed_loop = data["last_closed_loop"]
        if isinstance(data.get("last_validation"), dict):
            runtime.last_validation = data["last_validation"]
        resume_teaching = bool(data.get("teaching", False))
    except Exception as exc:
        print(f"State load ignored: {type(exc).__name__}: {exc}", flush=True)
    return runtime, resume_teaching


RUNTIME, RESUME_TEACHING = load_runtime()


def persist_state() -> None:
    with RUNTIME.network.lock:
        value = {
            "version": 2,
            "saved_at_unix": time.time(),
            "areas": [edge.area for edge in RUNTIME.network.directed_edges],
            "physics_parameters": {
                name: getattr(RUNTIME.network, name)
                for name in RUNTIME.network.PHYSICS_PARAMETER_NAMES
            },
            "background_rate": RUNTIME.network.background_rate,
            "speed": RUNTIME.speed,
            "teaching_cycles": RUNTIME.teaching_cycles,
            "teach_expression": RUNTIME.teach_expression,
            "teach_label": RUNTIME.teach_label,
            "teaching": RUNTIME.teaching,
            "registry": RUNTIME.registry.to_dict(),
            "last_closed_loop": RUNTIME.last_closed_loop,
            "last_validation": RUNTIME.last_validation,
        }
    temporary = STATE_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, separators=(",", ":")), encoding="utf-8")
    os.replace(temporary, STATE_FILE)


def persistence_loop(stop_event: threading.Event) -> None:
    while not stop_event.wait(5.0):
        try:
            persist_state()
        except Exception as exc:
            print(f"State save failed: {type(exc).__name__}: {exc}", flush=True)


def body_json(handler: BaseHTTPRequestHandler) -> dict[str, Any]:
    length = int(handler.headers.get("Content-Length", "0"))
    if length <= 0:
        return {}
    if length > 1_000_000:
        raise ValueError("Request body is too large")
    return json.loads(handler.rfile.read(length).decode("utf-8"))


class Handler(BaseHTTPRequestHandler):
    server_version = "EightNeuronConnection/0.3"

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"{self.client_address[0]} - {fmt % args}", flush=True)

    def send_json(self, value: Any, status: int = 200) -> None:
        payload = json.dumps(value, separators=(",", ":"), allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(payload)

    def send_file(self, path: Path) -> None:
        try:
            path = path.resolve(strict=True)
        except FileNotFoundError:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        if not path.is_file() or STATIC.resolve() not in path.parents:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        payload = path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", mimetypes.guess_type(path.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:
        path = urllib.parse.urlparse(self.path).path
        if path in ("/health", "/api/health"):
            self.send_json({
                "ok": True,
                "service": "eight-neuron-connection",
                "title": PhysicsNetwork.TITLE,
                "version": PhysicsNetwork.VERSION,
                "patterns": len(RUNTIME.registry.records),
                "activity": RUNTIME.network.metrics(),
            })
            return
        if path == "/api/state":
            self.send_json(RUNTIME.snapshot())
            return
        if path == "/api/patterns":
            self.send_json({"ok": True, "patterns": RUNTIME.registry.summaries()})
            return
        if path == "/api/model":
            self.send_json({
                "title": PhysicsNetwork.TITLE,
                "version": PhysicsNetwork.VERSION,
                "claim": "closed-loop emergent temporal-pattern learning under local energy and conductance laws",
                "boundary": "labels are post-hoc metadata and are never injected as target neuron patterns",
                "equations": {
                    "resistance": "R_ij = rho L_ij / A_ij",
                    "conductance": "G_ij = A_ij / (rho L_ij)",
                    "energy_split": "Q_ij = Q_i G*_ij / sum_k G*_ik",
                    "arrival": "Q_arrival = exp(-kappa L/A) Q_sent",
                    "pattern": "F[i,b] = spike count of neuron i in time bin b",
                },
            })
            return
        if path in ("/", "/index.html"):
            self.send_file(STATIC / "index.html")
            return
        self.send_file(STATIC / path.lstrip("/"))

    def do_POST(self) -> None:
        try:
            data = body_json(self)
            path = urllib.parse.urlparse(self.path).path
            if path == "/api/teach/closed-loop":
                expression = str(data.get("expression", "1+1"))
                label = str(data.get("label", "2"))
                max_cycles = int(data.get("max_cycles", 100))
                report = RUNTIME.teach_until_stable(
                    expression,
                    label,
                    min_cycles=30,
                    max_cycles=max_cycles,
                    block_cycles=10,
                    validation_trials=3,
                )
                persist_state()
                self.send_json({
                    "ok": True,
                    "result": report,
                    "note": "Training stopped automatically at the best validated physical checkpoint.",
                })
                return
            if path == "/api/validate":
                report = RUNTIME.evaluate_memory(
                    trials=int(data.get("trials", 7)),
                    negative_limit=int(data.get("negative_limit", 4)),
                )
                persist_state()
                self.send_json({"ok": True, "result": report})
                return
            if path == "/api/teach/start":
                expression = str(data.get("expression", "1+1"))
                label = str(data.get("label", "2"))
                RUNTIME.start_teaching(expression, label)
                persist_state()
                self.send_json({
                    "ok": True,
                    "teaching": True,
                    "expression": RUNTIME.teach_expression,
                    "label": RUNTIME.teach_label,
                    "note": "Only the input expression enters the network; the label is observation metadata.",
                })
                return
            if path == "/api/teach/stop":
                RUNTIME.stop_teaching()
                persist_state()
                self.send_json({"ok": True, "teaching": False, "cycles": RUNTIME.teaching_cycles})
                return
            if path == "/api/teach/batch":
                expression = str(data.get("expression", "1+1"))
                label = str(data.get("label", "2"))
                cycles = int(data.get("cycles", 30))
                result = RUNTIME.run_teaching_cycles(expression, label, cycles)
                persist_state()
                self.send_json({"ok": True, "cycles_run": cycles, "result": result})
                return
            if path == "/api/ask":
                expression = str(data.get("expression", "1+1"))
                trials = int(data.get("trials", 7))
                result = RUNTIME.ask(expression, trials=trials)
                self.send_json({"ok": True, "result": result})
                return
            if path == "/api/inject":
                bits = data.get("bits")
                RUNTIME.network.inject_bits(bits)
                self.send_json({"ok": True, "bits": bits})
                return
            if path == "/api/reset/dynamic":
                RUNTIME.network.clear_dynamic_state(randomise=True)
                self.send_json({"ok": True, "reset": "dynamic"})
                return
            if path == "/api/reset/memory":
                RUNTIME.reset_all_memory()
                persist_state()
                self.send_json({"ok": True, "reset": "structural-and-pattern-memory"})
                return
            if path == "/api/runtime":
                if "speed" in data:
                    RUNTIME.speed = max(0.25, min(float(data["speed"]), 50.0))
                if "background_rate" in data:
                    RUNTIME.network.background_rate = max(0.0, min(float(data["background_rate"]), 12.0))
                persist_state()
                self.send_json({
                    "ok": True,
                    "speed": RUNTIME.speed,
                    "background_rate": RUNTIME.network.background_rate,
                })
                return
            self.send_error(HTTPStatus.NOT_FOUND)
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            self.send_json({"ok": False, "error": str(exc)}, status=400)
        except Exception as exc:  # pragma: no cover
            self.send_json({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, status=500)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default=os.environ.get("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8788")))
    args = parser.parse_args()

    server = ThreadingHTTPServer((args.host, args.port), Handler)
    RUNTIME.start()
    if RESUME_TEACHING:
        try:
            RUNTIME.start_teaching(RUNTIME.teach_expression, RUNTIME.teach_label)
        except ValueError as exc:
            print(f"Saved teaching state not resumed: {exc}", flush=True)

    stop_event = threading.Event()
    saver = threading.Thread(target=persistence_loop, args=(stop_event,), daemon=True)
    saver.start()

    def shutdown(*_: object) -> None:
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    print(f"{PhysicsNetwork.TITLE} v{PhysicsNetwork.VERSION} listening on http://{args.host}:{args.port}", flush=True)
    try:
        server.serve_forever(poll_interval=0.25)
    finally:
        stop_event.set()
        RUNTIME.stop()
        persist_state()
        server.server_close()


if __name__ == "__main__":
    main()
