# 8 Neuron Connection v0.3.0

A physics-first recurrent-network experiment with an automatic closed testing loop.

## Normal workflow

1. **Teach & validate**: enter an input and a human label. The label never enters the physical network.
2. The system trains in bounded blocks, validates every stored pattern against unrelated controls, and retains the best physical checkpoint.
3. **Ask**: enter an input and observe the matched emergent temporal pattern or `UNKNOWN`.
4. **Run full validation** at any time to test all named memories and unknown controls.

## v0.3.0 changes

- Plasticity was reduced to a robust slow regime selected by multi-seed experiments.
- Automatic early stopping prevents indefinite overtraining.
- Drift and path-polarisation guards restore the best checkpoint.
- Validation checks all known memories, unknown rejection, energy balance and structural dispersion.
- The UI exposes a simple Teach → Ask → Output workflow and a visible validation result.
- A reproducible 20-seed, four-pattern benchmark is included.

## Run

```bash
python3 app.py --host 127.0.0.1 --port 8788
```

## Test

```bash
python3 -m unittest discover -s tests -v
python3 experiments/closed_loop_benchmark.py --seeds 20 --workers 4 --max-cycles 100
```

This model demonstrates labelled emergent temporal-pattern recognition and bounded continual learning. It does not yet demonstrate abstract arithmetic generalisation.
