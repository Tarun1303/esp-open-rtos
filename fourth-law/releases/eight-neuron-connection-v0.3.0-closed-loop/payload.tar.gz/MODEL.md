# 8 Neuron Connection v0.3.0 — closed-loop physical learning

## Physical kernel

Each neuron stores finite activation energy. It fires after crossing its local threshold, divides a finite discharge among outgoing paths according to effective conductance, and loses energy through leakage and transmission.

For path area \(A_{ij}\), length \(L_{ij}\), and resistivity \(\rho\):

\[
R_{ij}=\rho\frac{L_{ij}}{A_{ij}},\qquad
G_{ij}=\frac{A_{ij}}{\rho L_{ij}}.
\]

A discharge \(Q_i\) is divided without energy multiplication:

\[
Q_{ij}=Q_i\frac{G^*_{ij}}{\sum_kG^*_{ik}}.
\]

Repeated causal flow slowly modifies path area. v0.3.0 uses the validated operating point:

\[
\alpha_{causal}=0.0025,\quad
\alpha_{flux}=0,\quad
\beta_{relax}=0.001,\quad
\tau_{eligibility}=0.35.
\]

These are physical medium constants, not output-specific weights.

## Emergent output

No output neuron code is predefined. An input produces an 8-neuron by 24-time-bin response:

\[
F_{i,b}=\text{spike count of neuron }i\text{ in time bin }b.
\]

The human label is attached only after this temporal pattern is observed. Recall uses shifted cosine similarity and returns `UNKNOWN` unless the evidence floor and inter-pattern margin are satisfied.

## Closed testing loop

Training proceeds in blocks of ten physical episodes. After each block, the observation layer:

1. asks every registered source input;
2. verifies that it recalls its own pattern ID;
3. tests unrelated controls for `UNKNOWN`;
4. checks mean pattern stability;
5. checks path-area dispersion;
6. verifies the energy-ledger residual.

A structural and registry checkpoint is retained whenever the objective improves. Training stops when two consecutive validations pass, or when a drift/plasticity guard triggers. The best passing checkpoint is restored automatically.

The loop changes no neuron based on a correct label. It only decides how long to expose the physical network and which already-observed checkpoint to retain.

## Validation boundary

Passing the closed loop proves repeatable, selective temporal association under the tested inputs. It does not prove symbolic arithmetic or general intelligence.
